import CMovie from "./movie-card";
import CUser from "./user-card";

export { CMovie, CUser }