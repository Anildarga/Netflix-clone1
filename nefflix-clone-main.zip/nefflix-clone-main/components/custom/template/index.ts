import { EmailTemplate } from "./email-template";

export {
    EmailTemplate
}