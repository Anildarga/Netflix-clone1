import MovieSearch from "./movie-search";

export { MovieSearch }