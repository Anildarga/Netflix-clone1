import { Fragment } from "react";
import { MMovie } from "../modals";

const ModalsProvider = () => {
  return (
    <Fragment>
      <MMovie />
    </Fragment>
  );
};

export default ModalsProvider;
