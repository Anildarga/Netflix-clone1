import MMovie from "./movie.modal";

export { MMovie }