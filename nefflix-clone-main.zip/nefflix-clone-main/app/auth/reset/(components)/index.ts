import TNewPassword from "./new-password.tab";
import TReset from "./reset.tab";


export { TNewPassword, TReset };
