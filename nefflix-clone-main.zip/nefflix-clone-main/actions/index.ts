import { useMovies } from "./use-movies";

export { useMovies }